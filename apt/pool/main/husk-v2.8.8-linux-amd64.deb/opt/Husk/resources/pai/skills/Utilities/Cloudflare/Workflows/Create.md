# Create Cloudflare Worker or MCP Server

Deploy a new Cloudflare Worker or MCP server.

Running the **Create** workflow in the **Cloudflare** skill to deploy a new worker...

## Project Structure

```
workers/mcp-server-name/
├── src/
│   └── simple.js      # Main worker code
├── wrangler.toml      # Cloudflare config
├── package.json       # Dependencies
└── README.md          # Documentation
```

## Essential wrangler.toml

```toml
name = "mcp-server-name"
main = "src/simple.js"
compatibility_date = "2024-01-01"
account_id = "$CLOUDFLARE_ACCOUNT_ID"

[vars]
MCP_SERVER_NAME = "your-server"
MCP_SERVER_VERSION = "1.0.0"
```

## Deployment

```bash
# CRITICAL: Must unset environment variables that interfere
cd workers/mcp-server-name
(unset CF_API_TOKEN && unset CLOUDFLARE_API_TOKEN && wrangler deploy)
```

## Post-Deploy Verification via MCP

After wrangler deploy succeeds, verify the worker is live using Code Mode MCP:

1. **Confirm worker exists in account:**
   ```
   MCP execute("GET /accounts/{account_id}/workers/scripts")
   ```
   Verify the worker name appears in the response.

2. **Check worker details:**
   ```
   MCP execute("GET /accounts/{account_id}/workers/scripts/{script_name}")
   ```
   Confirm the script has the expected bindings, routes, and compatibility date.

3. **Test endpoints:**
   ```bash
   # Test root endpoint
   curl https://your-server.your-account.workers.dev/

   # Test tool execution
   curl -X POST https://your-server.your-account.workers.dev/call \
     -H "Content-Type: application/json" \
     -d '{"name": "tool_name", "arguments": {...}}'
   ```

## MCP Server Endpoints

- Root `/` - Server info
- `/tools` - List available tools
- `/call` - Execute tools (POST)
- Always include CORS headers
- Return proper JSON responses

## Key Details

- **Account ID:** Configure your Cloudflare account ID in wrangler.toml
- **Always unset** CF_API_TOKEN and CLOUDFLARE_API_TOKEN before deploying
- **URL format:** `https://[worker-name].your-account.workers.dev`

## Cloudflare Documentation

For MCP server specifics: https://developers.cloudflare.com/agents/guides/remote-mcp-server/
